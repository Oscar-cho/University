import sys

def dfs(graph, node, visited):
    visited[node] = True
    count = 0
    for neighbor, _ in graph[node]:
        if not visited[neighbor]:
            count += dfs(graph, neighbor, visited)
    return count + 1

T = int(input())  # 테스트 케이스 수 입력

for _ in range(T):
    N, M = map(int, input().split())  # 국가 수와 비행기 종류 수 입력
    
    graph = [[] for _ in range(N + 1)]
    for _ in range(M):
        u, v = map(int, sys.stdin.readline().split())
        graph[u].append((v, 1))
        graph[v].append((u, 1))
    
    visited = [False] * (N + 1)
    result = dfs(graph, 1, visited) - 1  # 시작 국가를 1로 가정하여 탐색
    
    print(result)
