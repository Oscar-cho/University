import heapq

n = int(input())
q = []

for i in range(n):
    op = list(map(int, input().split()))
    if op[0] == 0:
        if not q:
            print(-1)
        else:
            print(-heapq.heappop(q))
    else:
        for j in range(1, len(op)):
            heapq.heappush(q, -op[j])
