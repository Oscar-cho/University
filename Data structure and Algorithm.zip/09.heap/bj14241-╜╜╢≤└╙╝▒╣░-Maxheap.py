from MaxHeap import MaxHeap

n = int(input())
m = list(map(int, input().split()))

slimes = MaxHeap()
for _ in m:
    slimes.insert(_)
    
result = 0
while slimes.size() > 1:
    a = slimes.pop()
    b = slimes.pop()
    result += a * b
    slimes.insert(a+b)

print(result)
