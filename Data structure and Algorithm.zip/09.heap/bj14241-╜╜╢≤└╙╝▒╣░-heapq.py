import heapq

n = int(input())
slimes = list(map(int, input().split()))

heapq.heapify(slimes)

result = 0

while len(slimes) > 1:
    a = heapq.heappop(slimes)
    b = heapq.heappop(slimes)
    result += a * b
    heapq.heappush(slimes, a+b)

print(result)
