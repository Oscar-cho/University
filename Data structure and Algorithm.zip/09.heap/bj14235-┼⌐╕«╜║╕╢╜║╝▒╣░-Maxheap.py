from MaxHeap import MaxHeap

n = int(input())
q = MaxHeap()

for i in range(n):
    op = list(map(int, input().split()))
    if op[0] == 0:
        if q.size() == 0:
            print(-1)
        else:
            print(q.pop())
    else:
        for j in range(1, len(op)):
            q.insert(op[j])
    