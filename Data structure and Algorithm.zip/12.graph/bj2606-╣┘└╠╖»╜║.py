from collections import deque
import sys

def dfs(graph, root):
    size = len(graph)
    visited = []
    discovered = [False] * size
    distance = [float('inf')] * size
    
    stack = [root]
    discovered[root] = True
    distance[root] = 0
    
    while stack:
        visit = stack.pop()
        visited.append(visit)
        for n in range(size-1, -1, -1):
            if graph[visit][n] and not discovered[n]:
                stack.append(n)
                discovered[n] = True
                distance[n] = distance[visit] + 1
                
    return visited, distance

n = int(input())  # 컴퓨터의 수
m = int(input())  # 간선의 수

graph = [[False] * (n+1) for _ in range(n+1)]  # 1부터 n까지의 인덱스 사용

for _ in range(m):
    a, b = map(int, input().split())
    graph[a][b] = graph[b][a] = True

root = 1  # 시작 노드는 1로 가정
visited, distance = dfs(graph, root)

print(len(visited) - 1)  # 방문한 컴퓨터의 수 출력
