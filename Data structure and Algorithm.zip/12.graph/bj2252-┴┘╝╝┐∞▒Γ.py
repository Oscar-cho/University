import sys

def dfs(graph, root, visited, result):
    visited[root] = True
    for n in graph[root]:
        if not visited[n]:
            dfs(graph, n, visited, result)
    result.append(root)

N, M = map(int, input().split())  # 학생의 수와 키 비교 쌍의 수 입력

graph = [[] for _ in range(N + 1)]
for _ in range(M):
    a, b = map(int, sys.stdin.readline().split())
    graph[b].append(a)  # 간선의 방향을 반대로 저장

visited = [False] * (N + 1)
result = []

for i in range(1, N + 1):
    if not visited[i]:
        dfs(graph, i, visited, result)

result.reverse()

print(*result)
