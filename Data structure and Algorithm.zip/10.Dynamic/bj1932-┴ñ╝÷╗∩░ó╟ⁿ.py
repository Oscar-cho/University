import sys
sys.stdin = open('bj1932.txt' , 'r')

def max_path(row, col):
    if row == _size - 1:
        return _triangle[row][col]
    
    path_left = _triangle[row][col] + max_path(row+1, col)
    path_right = _triangle[row][col] + max_path(row+1, col+1)
    
    return max(path_left, path_right)

_triangle = []
_size = int(input())

for _ in range(_size):
    _triangle.append(list(map(int, input().split())))
    
# 초기값 설정
dp = [[0] * (_size + 1) for _ in range(_size + 1)]

# 바닥부터 시작하여 각 위치까지의 최대 경로 합 계산
for row in range(_size - 1, -1, -1):
    for col in range(row + 1):
        dp[row][col] = max_path(row, col)

print(dp[0][0])