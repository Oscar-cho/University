import sys

def knapsack(capacity, item):
    if capacity == 0 or item >= _number:
        return 0
    
    if _weight[item] > capacity:
        return knapsack(capacity, item+1)
    
    if dp[item][capacity] != -1:
        return dp[item][capacity]
    
    with_the_item = _value[item] + knapsack(capacity - _weight[item], item+1)
    without_the_item = knapsack(capacity, item+1)
    
    dp[item][capacity] = max(with_the_item, without_the_item)
    return dp[item][capacity]

_number, _capacity = map(int, input().split())

_weight = []
_value = []

for _ in range(_number):
    w, v = map(int, input().split())
    _weight.append(w)
    _value.append(v)

# 초기값 설정
dp = [[-1] * (_capacity + 1) for _ in range(_number + 1)]

result = knapsack(_capacity, 0)
print(result)
