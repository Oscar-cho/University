def hanoi(disks, src, dst, extra):
    if disks==1:
        hanoi.count += 1
        print(f'{hanoi.count}: move from {src} to {dst}')
        
    else:
        hanoi(disks-1, src, extra, dst)
        hanoi.count += 1
        print(f'{hanoi.count}: move from {src} to {dst}')
        hanoi(disks-1, extra, dst, src)
        
hanoi.count = 0
hanoi(3, 1, 3, 2)