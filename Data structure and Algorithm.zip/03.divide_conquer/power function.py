def power(base, exponent):
    if exponent == 0:
        return 1
    else:
        return base * power(base, exponent-1)
    
a, b = 5, 3
print("%d**%d = %d" % (a, b, power(a,b)))