def bit_str(ans):
    if len(ans) == n:
        print(*ans)
        
    else:
        for s in data:
            ans.append(s)
            bit_str(ans)
            ans.pop()
            
n ,  data = 3, 'abc'
bit_str([])