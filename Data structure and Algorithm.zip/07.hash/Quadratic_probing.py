from typing import List, Union


class HashTableLinear:
    def __init__(self):
        self.size = 1000000
        self.slots: List[Union[None, str]] = [None for _ in range(self.size)]
        
    def compute_hash(self, key: str):
        h = sum(map(ord,key)) % self.size
        return h
    
    
    def insert(self, key: str):
        index = self.compute_hash(key)
        for probe in range(self.size):
            index = (index + probe*probe) % self.size
            if self.slots[index] is None:
                self.slots[index] = key
                return index
        return -1
    
     def search(self, key: str):
        index = self.compute_hash(key)
        for probe in range(self.size):
            index = (index + probe*probe) % self.size
            if self.slots[index] == key:
                return True
        return False

sys.stdin = open('bj5052.txt', 'r')

tc = int(input())
for _ in range(tc):
    phone_book = HashTable1()
    check = []
    n = int(input())
    for _ in range(n):
        number = sys.stdin.readline().strip()
        phone_book.insert(number)
        check.append(number)
        
    ans = True
    for number in check:
        for i in range(1, len(number)):
            prefix = number[:-i]
            if phone_book.search(prefix):
                ans = False
                break
        if not ans:
            break
            
    if ans:
         print("YES") 
    else:     
        print("NO") 