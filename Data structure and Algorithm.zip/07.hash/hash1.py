from hash_table import Hashtable1

ht = HashTable1()
ht.insert('dog')
ht.insert('cat')
ht.insert('turtle')
ht.insert('bird')

print('Contains dog? %s' % ht.search('dog'))
print('Contains cat? %s' % ht.search('cat'))
print('Contains fish? %s' % ht.search('fish'))

