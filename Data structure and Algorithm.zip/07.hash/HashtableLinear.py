from typing import List, Union


class HashTableLinear:
    def __init__(self):
        self.size = 10
        self.slots: List[Union[None, str]] = [None for _ in range(self.size)]
        
    def compute_hash(self, key: str):
        h = sum(map(ord,key)) % self.size
        return h
    
    def insert(self, key: str):
        index = self.compute_hash(key)
        for probe in range(self.size):
            index = (index + probe) % self.size
            if self.slots[index] is None:
                self.slots[index] = key
                return index
        return -1
    
    def search(self, key: str):
        index = self.compute_hash(key)
        for probe in range(self.size):
            index = (index + probe) % self.size
            if self.slots[index] == key:
                return True
        return False
    
    
    