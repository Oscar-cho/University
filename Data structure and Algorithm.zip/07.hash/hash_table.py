from typing import List, Union


class Node1:
    def __init__(self, key:str):
        self.key = key
        self.next = None
        
        
#Each item has only a key      
class Hashtable1:
    def __init__(self):
        self.size = 10
        self.slots: List[Union[None, Node1]] = [None for _ in range(self.size)]
        
        
    def compute_hash(self, key: str):
        h = sum(map(ord, key)) % self.size
        return h
    
    def insert(self, key:str):
        node = Node1(key)
        index = self.compute_hash(key)
        
        #insert as the head node
        node.next = self.slots[index]
        self.slots[index] = node
        
    def search(self, key:str) -> bool:
        index = self.compute_hash(key)
        current = self.slots[index]
        
        while current:
            if current.key == key:
                return True
            current = current.next
        return False
    
    