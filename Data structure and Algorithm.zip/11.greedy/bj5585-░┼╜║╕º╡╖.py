import sys
sys.stdin = open('bj5585.txt', 'r')

n = int(input())

change = 1000 - n  # 거스름돈 계산

coins = [500, 100, 50, 10, 5, 1]  # 동전 종류

count = 0  # 동전 개수 카운트

for coin in coins:
    count += change // coin  # 해당 동전으로 거스름돈을 최대한 사용
    change %= coin  # 남은 거스름돈 갱신

print(count)
