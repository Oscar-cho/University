import sys

n = int(input())
acts = []
for _ in range(n):
    a, b = map(int, sys.stdin.readline().split())
    acts.append((a, b))

acts.sort(key=lambda x: (x[1], x[0]))  # 종료 시간을 기준으로 오름차순, 종료 시간이 같다면 시작 시간이 빠른 순으로 정렬

count = 1  # 첫 번째 활동은 무조건 선택
end_time = acts[0][1]  # 첫 번째 활동의 종료 시간

for i in range(1, n):
    start_time, finish_time = acts[i]
    if start_time >= end_time:  # 현재 활동의 시작 시간이 이전 활동의 종료 시간 이후라면 선택
        count += 1
        end_time = finish_time

print(count)
