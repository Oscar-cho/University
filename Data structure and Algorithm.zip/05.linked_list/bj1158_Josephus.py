n, k = map(int, input().split())
jo = [i for i in range(1 , n+1)]

answer = []
num = 0

for j in range(n):
    num += k-1
    if num >= len(jo):
        num = num % len(jo)
        
    answer.append(str(jo.pop(num)))
print("<", ", ".join(answer), ">", sep='')

'''Queue 이용'''
from collections import deque

N, K = map(int,input().split())

q = deque(list(k+1 for k in range(N)))
ans = []

cnt = 0
while q:
    cnt += 1

    tmp = q.popleft()

    if cnt == K:
        ans.append(tmp)
        cnt = 0
    else:
        q.append(tmp)

print('<', ', '.join(map(str,ans)),'>',sep='')

