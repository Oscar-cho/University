from linkedlist import CircularSLL

words = CircularSLL()
words.insert(None, 'eggs')
words.insert(words.head, 'ham')
words.insert(words.head, 'spam')

for word in words.traverse():
    print(word)