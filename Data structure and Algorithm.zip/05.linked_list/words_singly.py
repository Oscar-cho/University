from linkedlist import SinglyLinkedList

words = SinglyLinkedList()
words.insert(None, 'eggs')
words.insert(words.head, 'ham')

for word in words.traverse():
    print(word)
    

