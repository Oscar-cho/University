import sys
from collections import deque

sys.stdin = open('bj3584.txt', 'r')

T = int(input())
N = int(input())
depth = [0] * (N+1)
parent = [0] * (N+1)
child = [[] for _ in range(N+1)]

for _ in range(N -1):
    p, c = map(int, sys.stdin.readline().split())
    parent[c] = p       
    child[p].append(c)


def set_depth(root):
    q = deque()
    q.append(root)

    while len(q) > 0:
        node = q.popleft()
        for j in range(len(child[node])):
            q.append(child[node][j])
            depth[child[node][j]] = depth[node] + 1
            
def lca(u, v):
    while u != v:
        if depth[u] > depth[v]:
            u = parent[u]  # 한칸 올려줌
        else:
            v = parent[v]  #한칸 올려줌
            
    return u # return v와 결과 동일

_root = 0
for i in range(1, N+1):
    if parent[i] == 0:
        _root = i
        break
set_depth(_root)

print(lca(a[0], b[0]))
