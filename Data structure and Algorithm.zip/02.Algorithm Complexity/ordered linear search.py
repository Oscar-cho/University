import random

def search(ordered_list, target):
    ordered_list_size = len(ordered_list)
    for i in range(ordered_list_size):
        if target == ordered_list[i]:
           return i
        elif ordered_list[i] > target:
            return None
        
    return None

# random sampling without replacement
test = random.sample(range(1, 15), 10) # sample은 random한 수를 뽑는 문제에서 중복을 허용하지 않음 
test.sort()
print(test)

_target = 11
result = search(test, _target)
if result is None:
    print('%s is not found.' % _target)
else:
    print('%s is at index %s' % (_target, result))
