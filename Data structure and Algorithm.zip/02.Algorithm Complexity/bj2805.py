import sys

sys.stdin = open('bj2805.txt', 'r')             # 입력을 keyboard가 하는게 아니라 bj2805라는 text의 값을 입력으로 설정. 'r'은 읽기 전용이라는 뜻

n, m = map(int, input().split())                # txt file의 input을 split
woods = list(map(int, input().split()))         # txt file의 input을 list로 만듬

left, right = 0, max(woods)                     # binary search 할 때 index를 나타내기 위해
h = left                                        # left의 초기값은 0

while left <= right:                            # binary search model 만들기
    mid = (left + right) // 2                   # 중간을 가르키는 index를 맞춰줌
    cut = 0                                     # 잘라진 나무의 초기값을 0으로 설정

    for tree in woods:
        if tree > mid:                          # 나무의 높이가 절단기의 높이보다 크다면
            cut += tree - mid                   # 잘라준다

    if cut >= m:                                # 자른 나무들의 길이의 합이 목표값 이상이라면
        left = mid + 1                          # left가 가르키는 index를 조절해준다

    else:                                       # 자른 나무들의 길이의 합이 목표값 이하라면
        right = mid - 1                         # right가 가르키는 index를 조절해준다

print(right)                                    # 결과를 출력한다

