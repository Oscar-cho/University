import random


def search(unordered_list, target):
    for i in range(len(unordered_list)):
        if target == unordered_list[i]:
            return i

    return None

test=[]
for _ in range(10):
    ## random integer n such that 1<= n <= 15
    n = random.randint(1,15)
    test.append(n)
print(test)

_target = 11
result = search(test, _target)
if result is None:
    print('%s is not found.' %_target)
else:
    print('%s is at index %s' %(_target, result))
