import numpy as np
from itertools import product
import matplotlib.pyplot as plt
import random
from tqdm import tqdm


class FourierEstimator:
    def __init__(self, env, n, alpha):
        self.n = n
        self.k = 2     
        self.n_action = 4
        self.alpha = alpha
        self.w = np.zeros([pow(self.n + 1, self.k), self.n_action])
        self.env = env
        self.alpha_vec = self.setting_alphas()
        
    def setting_alphas(self):
        orders = list(range(self.n + 1))
        c = list(product(orders, repeat = self.k))
        norm_c = np.linalg.norm(c, axis = 1)
        norm_c[0] = 1.
        return self.alpha / norm_c
    
    def normalize(self, state):
        norm_state = np.empty(np.shape(state))
        min_state = (0, 0)
        max_state = (100, 100)       
        
        for i in range(np.shape(state)[0]):
            state_range = max_state[i] - min_state[i]
            norm_state[i] = float(state[i] - min_state[i]) / state_range
        return norm_state
    
    def get_features(self, state):
        norm_state = self.normalize(state)
        orders = list(range(self.n + 1))
        c = list(product(orders, repeat = self.k))
        return np.cos(np.pi * np.dot(c, norm_state))
    
    def predict_values(self,state):
        return np.dot(self.w.T , self.get_features(state))
    
    def update_weights(self, state, action, target):
        q_values = self.predict_values(state)
        current_q = q_values[action]
        delta = target - current_q
        features = self.get_features(state)
        self.w[:, action] += delta * self.alpha_vec * features
        
    def get_action(s, estimator, epsilon=0):
        values = estimator.predict_values(s)
        a = np.argmax(values)
        if np.random.rand(1) < epsilon:
            a = np.random.randint(4)
            if a == 0 : # down
                actions[0]

            elif a == 1: # left
                actions[1]
                
            elif a == 2:
                actions[2]

            elif a == 3: # right
                actions[3]
                
        return a
    
    def semi_gradient_sarsa(env, estimator, num_episodes, gamma, epsilon=0):
        step_count = [0] * num_episodes
        for ep in tqdm(range(num_episodes)):
            state = env.reset()
            action = get_action(state, estimator)
            terminated = False
            
            while not terminated:
                step_count[ep] += 1
                next_state, reward, terminated, _ = env.step(action)
                next_action = get_action(next_state, estimator)
                terminated = env.terminal()
                
                if terminated:
                    target = reward
                else:
                    q_values = estimator.predict_values(next_state)
                    next_q = q_values[next_action]
                    target = reward + gamma * next_q
                estimator.update_weights(state, action, target)
                state = next_state
                action = next_action
                
        return step_count


class GridWorld():
    
    def __init__(self, size=100, max_step=500):
        self.start_x = 10 * random.random()
        self.start_y = 10 * random.random()
        self.reset()
        
    def reset(self): 
        self.state = (self.start_x, self.start_y)
        self.step_count = 0
        
    def step(self, action):
        reward = -1
        actions =  [np.array([0, -1]),
                    np.array([-1, 0]),
                    np.array([0, 1]),
                    np.array([1, 0])]
        
        if action == 0 : # down
            self.state += actions[0]
        elif action == 1: # left
            self.state += actions[1]
        elif action == 2: # up
            self.state += actions[2]
        elif action == 3: # right
            self.state += actions[3]

        return self.state, reward

    def terminal(self):
        return self.state[0] >= self.size - 10 or self.state[1] >= self.size - 10

env = GridWorld()

base_alpha = 0.001
fourier_order = 3
estimator = FourierEstimator(env, fourier_order, base_alpha)

num_episodes = 1000
gamma = 1

steps = semi_gradient_sarsa(env, estimator, num_episodes, gamma)

plt.plot(steps)
plt.title('Number of steps in an episode')
plt.xlabel('episode')
plt.ylabel('steps')
plt.show()