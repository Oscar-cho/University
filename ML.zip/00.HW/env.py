import numpy as np
import random

class GridWorld():
    
    def __init__(self, size=100, max_step=500):
        X = 10 * random.randint
        y = 10 * random.randint
    def reset(self):
    
    def step(self, action):
        